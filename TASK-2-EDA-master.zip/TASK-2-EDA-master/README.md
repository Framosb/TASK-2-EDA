# TASK-2-EDA
Exploratory Data Analysis of  Credit One database
